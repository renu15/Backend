const app = require('./app')

test('test true', () => {
  expect(app).toBeTruthy()
})
