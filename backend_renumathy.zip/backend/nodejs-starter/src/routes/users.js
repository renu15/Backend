const express = require('express')
const users = require('../helpers/user')
const router = express.Router()
const debug = require('debug')('app:users')
const db = require('../models/index')
const { UniqueViolationError } = require('objection')

router.get('/', async (req, res) => {
  const firstName = req.query.firstName 
  const result = firstName ? await users.getAboutme_ContactmeByUser(firstName) : await users.getAllUsers()
  res.status(200).json(result)
})


router.get('/:id', async (req, res) => {
  const result = await users.getUserById(req.params.id)
  res.status(200).json(result)
})

module.exports = router

router.post('/', async (req, res) => {
  const result = await users.addUser(req.body)

  // handle error
  if (result.err) {
    const err = result.err
    if (err instanceof UniqueViolationError) {
      res.status(409).send({
        message: err.message,
        type: 'UniqueViolation',
        data: {
          columns: err.columns,
          table: err.table,
          constraint: err.constraint
        }
      })
    } else {
      res.status(500).send({
        message: err.message,
        type: 'UnknownError',
        data: {}
      });
    }

    return
  }

  res.status(200).json(result)
})

router.delete('/:id', async (req, res) => {
  const response = await users.deleteUser(req.params.id)
  res.json(response)
})

router.patch('/', async (req, res) => {
  const firstName = req.query.firstName
  const aboutmeString = req.body.aboutme
  const contactMeString = req.body.contactMe
  const result = await users.patchUser(firstName, aboutmeString, contactMeString)
  res.status(200).json(result)
})
