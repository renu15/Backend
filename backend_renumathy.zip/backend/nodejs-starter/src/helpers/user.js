const db = require('../models/user')

exports.getAllUsers = async function() {
  const users = await db.User.query().select()
  return users
}

exports.getUsersByFirstname = async function(firstName) {
  const usersByFirstname = await db.User.query().select().where('firstName', firstName)
  return usersByFirstname[0] || 'Not found'
}

exports.getUserById = async function(id) {
  const usersById = await db.User.query().select().where('id', id)
  return usersById[0] || 'Not found'
}

exports.getAboutme_ContactmeByUser = async function(firstName) {
  const aboutme_contactmeByFirstname = await db.User.query().select('aboutme','contactMe').where('firstName', firstName)
  return aboutme_contactmeByFirstname[0] || 'Not found'
}

exports.addUser = async function(user) {
  try {
    const response = await db.User.query().insert(user)
    return response
  } catch(err) {
    return { err }
  }
}

exports.patchUser = async function(firstName, aboutmeString, contactMeString) {
  try {
    const response = await db.User.query().update({aboutme:aboutmeString, contactMe:contactMeString}).where('firstName', firstName)
    return response
  } catch(err) {
    console.log(err)
    return { err }
  }
}


exports.deleteUser = async function(id) {
  const response = await db.User.query().where('id', id).del()
  return response
}

